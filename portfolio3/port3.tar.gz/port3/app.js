var app = angular.module('myApp', []);

app.controller('myController', function ($scope)
{
	mod = require('./readQs.js');
	obj = mod.readFile();
});
