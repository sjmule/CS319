var x = require('./readQs.js');

console.log(x.readFile());